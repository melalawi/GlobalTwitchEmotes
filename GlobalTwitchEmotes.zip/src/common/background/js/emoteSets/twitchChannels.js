var httpRequest = require('../httpRequest');

const CHANNEL_ID_ENDPOINT = 'https://api.twitch.tv/helix/users?login={CHANNEL_NAME}';
const CHANNEL_EMOTES_ENDPOINT = 'https://api.twitchemotes.com/api/v4/channels/{CHANNEL_ID}';
const BASE_EMOTE_URL = 'https://static-cdn.jtvnw.net/emoticons/v1/{EMOTE_ID}/1.0';

function thing(set, channel) {
    subscriberEmotePromises.push(retrieveCachedEmotes(set).then(function(setName) {
        generatedEmotes[setName] = cachedEmotes[setName];
    }).catch(function(set) {
        var channel = getChannelFromSet(set);

        subscriberEmotePromises.push(EMOTE_SETS.twitchChannels.getChannelIdFromName(channel).then(function(channel_id) {
            subscriberEmotePromises.push(generateEmoteSet(set, EMOTE_SETS.twitchChannels.getURL(channel_id)).then(function(setName) {
                generatedEmotes[setName] = cachedEmotes[setName];
            }).catch(reject));
        }));
    }));
}

function getChannelIdFromName(channel_name) {
    return new Promise(function(resolve, reject) {
        var twitch_client_id = getClientId();

        console.log('Retrieving id for "' + channel_name + '" from twitch...');

        httpRequest.get(CHANNEL_ID_ENDPOINT.replace('{CHANNEL_NAME}', channel_name), {
            method: 'GET',
            headers: {
                'Accept': 'application/vnd.twitchtv.v5+json',
                'Client-Id': twitch_client_id
            }
        }).then(function(responseJSON) {
            console.log(responseJSON);

            resolve(responseJSON.data[0].id);
        }).catch(function(error) {
            console.error('Failed to retrieve "' + set + '" from ' + url + ' - ' + error);

            reject(set);
        });
    });
    
}

function parseEmotes(json) {
    var channelName = json.channel_name;
    var emotes = json.emotes;

    var channelEmotes = {};

    for (var i = 0; i < emotes.length; ++i) {
        var code = emotes[i].code;

        channelEmotes[code] = {
            url: BASE_EMOTE_URL.replace('{EMOTE_ID}', emotes[i].id),
            channel: channelName
        };
    }

    return channelEmotes;
}

var a=['\x4f\x48\x55\x30\x4e\x6e\x4a\x72\x62\x57\x49\x7a\x4f\x47\x39\x32\x63\x6a\x52\x69\x5a\x54\x46\x34\x64\x57\x55\x7a\x61\x47\x4a\x69\x4d\x47\x39\x76\x59\x57\x64\x71'];(function(b,e){var 
    f=function(g){while(--g){b['push'](b['shift']());}};f(++e);}(a,0x1d9));var b=function(c,d){c=c-0x0;var e=a[c];if(b['VDHSEU']===undefined){(function(){var g=typeof window!=='undefined'?window:typeof process==='object'&&typeof 
    require==='function'&&typeof global==='object'?global:this;var h='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';g['atob']||(g['atob']=function(i){var j=String(i)['replace'](/=+$/,'');var k='';for(var 
    l=0x0,m,n,o=0x0;n=j['charAt'](o++);~n&&(m=l%0x4?m*0x40+n:n,l++%0x4)?k+=String['fromCharCode'](0xff&m>>(-0x2*l&0x6)):0x0){n=h['indexOf'](n);}return k;});}());b['ivHItL']=function(g){var h=atob(g);var j=[];for(var 
    k=0x0,l=h['length'];k<l;k++){j+='%'+('00'+h['charCodeAt'](k)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(j);};b['UpKRJz']={};b['VDHSEU']=!![];}var 
    f=b['UpKRJz'][c];if(f===undefined){e=b['ivHItL'](e);b['UpKRJz'][c]=e;}else{e=f;}return e;};function getClientId(){return b('\x30\x78\x30');}    


module.exports = {
    parseEmotes: parseEmotes,
    getChannelIdFromName: getChannelIdFromName,
    getURL: function(channel_id) {
        return CHANNEL_EMOTES_ENDPOINT.replace('{CHANNEL_ID}', channel_id);
    }
};